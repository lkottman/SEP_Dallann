/**
 * Version 1.0
 * 06.10.2020
 *
 * @module /dbConfig
 */

const config = {

    host: '131.173.64.49',
    user: 'dallmann_am',
    password: 'Eib5choowu',
    database: 'dallmann_am2020',
    url: 'jdbc:mysql://131.173.64.49:3306/dallmann_am2020?serverTimezone=gmt',
    dateStrings: 'date'

}

//export of this module
module.exports = config;
